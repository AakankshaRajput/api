<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Institute_model extends CI_Model
{
	public function __construct()
	{
		$this->load->database();
	}
	public function listing($value)
	{
		//
	}
	public function institute_form_insert($data)
   	{
   		//print_r($data); die();
   		 return $this->db->insert('institute',$data);
	}
	
	
}
