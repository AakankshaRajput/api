
<?php
foreach ($value as $key => $val) {
	foreach ($val as  $set) {
		echo $set.'<br>';
	}
}