<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Institute extends CI_Controller 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Institute_model');
		$this->load->library('session');
		if(!$this->session->userdata('admin_name')==true)
    {
      redirect(base_url().'login/logout');
    }
		
	}
	public function index()
	{
		$data['institute']=$this->db->get('institute')->result();
		$this->load->view('institute/index',$data);

	}
	public function add()
	{
		$this->load->view('institute/institute_form');
	}

	
	
	
	public function institute_form()
	{
		
		$institute_name=$this->input->post('institute_name');
		$institute_val=substr($institute_name,0,6);
		//$institute_value=str_shuffle($institute_val).'/'.mt_rand(10000,99999);
		$institute_value= uniqid($institute_val).mt_rand(10000,99999);
		$data = array(
		'institute_id'=>str_replace(' ','',$institute_value),
        'institute_name'=>$this->input->post('institute_name'),
        'discount'=>$this->input->post('discount'),
        'category'=>$this->input->post('category'),
        'package'=>$this->input->post('package'),
        'payment'=>$this->input->post('payment'),
        'min_purchase'=>$this->input->post('min_purchase'),
        'current_date_inst'=>$this->input->post('current_date_inst'),
    	);
    	
    	$this->Institute_model->institute_form_insert($data);
    	$this->session->set_flashdata('message', 'Data Saved Successful!');
   	 	redirect(base_url().'institute');
	}
}
